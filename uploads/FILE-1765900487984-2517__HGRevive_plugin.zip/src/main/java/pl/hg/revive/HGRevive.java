package pl.hg.revive;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class HGRevive extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("HGRevive enabled");
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Bukkit.getScheduler().runTask(this, () -> {
            p.setGameMode(GameMode.SPECTATOR);
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item.getType() != Material.WRITTEN_BOOK && item.getType() != Material.BOOK) return;
        if (!item.hasItemMeta()) return;
        if (!(item.getItemMeta() instanceof BookMeta meta)) return;
        if (!ChatColor.stripColor(meta.getTitle()).equalsIgnoreCase("Księga_Odrodzenia")) return;

        String targetName = e.getMessage().trim();
        Player target = Bukkit.getPlayerExact(targetName);
        e.setCancelled(true);

        if (target == null) {
            p.sendMessage(ChatColor.RED + "Nie znaleziono gracza.");
            return;
        }

        Bukkit.getScheduler().runTask(this, () -> {
            target.setGameMode(GameMode.SURVIVAL);
            p.sendMessage(ChatColor.GREEN + "Odrodzono gracza " + target.getName());
            item.setAmount(item.getAmount() - 1); // jednorazowa
        });
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!cmd.getName().equalsIgnoreCase("ksiega")) return false;
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            Player p = Bukkit.getPlayerExact(args[1]);
            if (p == null) return true;
            ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
            BookMeta meta = (BookMeta) book.getItemMeta();
            meta.setTitle("Księga_Odrodzenia");
            meta.setAuthor("Igrzyska");
            meta.addPage("Trzymaj i wpisz nick gracza na czacie.");
            book.setItemMeta(meta);
            p.getInventory().addItem(book);
        }
        return true;
    }
}
