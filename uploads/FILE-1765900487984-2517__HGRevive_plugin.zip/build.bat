@echo off
echo Budowanie pluginu HGRevive...
mvn package
pause
